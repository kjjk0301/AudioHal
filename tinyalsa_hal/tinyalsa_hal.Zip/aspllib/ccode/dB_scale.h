
extern float dB_scale[47];
extern float vol_scale[47];
extern float pow_scale[47];
extern int dB_scaleQ15[47];