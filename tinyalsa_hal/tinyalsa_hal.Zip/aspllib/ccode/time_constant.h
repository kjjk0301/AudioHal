
extern float tau_msec[23];
extern unsigned char gamma_inv[23];
extern short beta[23];
extern short round_bit[23];
extern float gamma_f[23];
extern float tau16k_msec[15];
extern float tau16k_90_msec[15];
extern float gamma16k[15];
extern short beta16k[15];
extern short round_bit16k[15];